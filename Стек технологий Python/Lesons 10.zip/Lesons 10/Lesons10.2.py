# Задание 2

my_dict = dict()
for i in range(10, -5-1, -1):
    my_dict[i] = i**i
print(my_dict)